import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class ReelVideoPlayer extends StatefulWidget {
  final String videoUrl;
  final String profileImageUrl;
  final String username;
  final String userId;

  const ReelVideoPlayer({
    required this.videoUrl,
    required this.profileImageUrl,
    required this.username,
    required this.userId,
  });

  @override
  _ReelVideoPlayerState createState() => _ReelVideoPlayerState();
}

class _ReelVideoPlayerState extends State<ReelVideoPlayer> {
  late VideoPlayerController _controller;
  late Future<void> _initializeVideoPlayerFuture;
  bool _showControls = true;
  bool _isFollowing = false;
  Timer? _hideControlsTimer;
  final String currentUserId = FirebaseAuth.instance.currentUser!.uid;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.network(widget.videoUrl);
    _initializeVideoPlayerFuture = _controller.initialize().then((_) {
      setState(() {});
      _controller.play();
      _controller.setLooping(true);
    });
    _checkIfFollowing();
    _startHideControlsTimer();
  }

  @override
  void dispose() {
    _controller.dispose();
    _hideControlsTimer?.cancel();
    super.dispose();
  }

  void _startHideControlsTimer() {
    _hideControlsTimer?.cancel();
    _hideControlsTimer = Timer(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() {
          _showControls = false;
        });
      }
    });
  }

  Future<void> _checkIfFollowing() async {
    DocumentSnapshot followingDoc = await FirebaseFirestore.instance
        .collection('users')
        .doc(currentUserId)
        .collection('following')
        .doc(widget.userId)
        .get();

    setState(() {
      _isFollowing = followingDoc.exists;
    });
  }

  Future<void> _toggleFollow() async {
    DocumentReference currentUserRef =
        FirebaseFirestore.instance.collection('users').doc(currentUserId);
    DocumentReference userToFollowRef =
        FirebaseFirestore.instance.collection('users').doc(widget.userId);

    if (_isFollowing) {
      await currentUserRef.collection('following').doc(widget.userId).delete();
      await userToFollowRef.collection('followers').doc(currentUserId).delete();
    } else {
      await currentUserRef.collection('following').doc(widget.userId).set({});
      await userToFollowRef.collection('followers').doc(currentUserId).set({});
    }

    setState(() {
      _isFollowing = !_isFollowing;
    });
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    return FutureBuilder(
      future: _initializeVideoPlayerFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          return GestureDetector(
            onTap: () {
              setState(() {
                _showControls = !_showControls;
              });
              if (_showControls) {
                _startHideControlsTimer();
              }
            },
            child: Stack(
              children: [
                Center(
                  child: _controller.value.isInitialized
                      ? SizedBox(
                          width: screenSize.width,
                          height: screenSize.height,
                          child: FittedBox(
                            fit: BoxFit.cover,
                            child: SizedBox(
                              width: _controller.value.size.width,
                              height: _controller.value.size.height,
                              child: VideoPlayer(_controller),
                            ),
                          ),
                        )
                      : CircularProgressIndicator(),
                ),
                if (_showControls)
                  Center(
                    child: IconButton(
                      iconSize: 60,
                      icon: Icon(
                        _controller.value.isPlaying
                            ? Icons.pause_circle_filled
                            : Icons.play_circle_filled,
                        color: Colors.white,
                      ),
                      onPressed: () {
                        setState(() {
                          if (_controller.value.isPlaying) {
                            _controller.pause();
                          } else {
                            _controller.play();
                            _startHideControlsTimer();
                          }
                        });
                      },
                    ),
                  ),
                Positioned(
                  bottom: 20,
                  left: 20,
                  right: 20,
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 20,
                        backgroundImage: widget.profileImageUrl.isNotEmpty
                            ? NetworkImage(widget.profileImageUrl)
                            : null,
                        child: widget.profileImageUrl.isEmpty
                            ? Icon(Icons.person, size: 20, color: Colors.white)
                            : null,
                      ),
                      SizedBox(width: 10),
                      Flexible(
                        child: Text(
                          widget.username,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            shadows: [
                              Shadow(
                                blurRadius: 10.0,
                                color: Colors.black,
                                offset: Offset(2.0, 2.0),
                              ),
                            ],
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      SizedBox(width: 10),
                      SizedBox(
                        width: 110,
                        height: 30,
                        child: OutlinedButton(
                          onPressed: _toggleFollow,
                          style: OutlinedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            side: BorderSide(
                              color: Colors.white,
                            ),
                          ),
                          child: Text(
                            _isFollowing ? 'Following' : 'Follow',
                            style: TextStyle(
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        } else if (snapshot.hasError) {
          return Center(child: Text('Error loading video: ${snapshot.error}'));
        } else {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.blueAccent),
                  strokeWidth: 6.0,
                ),
                SizedBox(height: 10),
                Text(
                  'Loading video...',
                  style: TextStyle(color: Colors.grey),
                ),
              ],
            ),
          );
        }
      },
    );
  }
}
