import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class FollowersScreen extends StatelessWidget {
  final String uid;

  const FollowersScreen({required this.uid});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Followers')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc(uid)
            .collection('followers')
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return Center(child: CircularProgressIndicator());
          }

          var followersDocs = snapshot.data!.docs;

          return ListView.builder(
            itemCount: followersDocs.length,
            itemBuilder: (context, index) {
              var followerId = followersDocs[index].id;
              return FutureBuilder<DocumentSnapshot>(
                future: FirebaseFirestore.instance
                    .collection('users')
                    .doc(followerId)
                    .get(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return ListTile(title: Text('Loading...'));
                  }

                  var followerData = snapshot.data!.data() as Map<String, dynamic>;
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundImage: NetworkImage(followerData['profileImageUrl']),
                    ),
                    title: Text(followerData['name']),
                    subtitle: Text(followerData['email']),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}